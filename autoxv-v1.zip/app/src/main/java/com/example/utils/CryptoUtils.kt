package com.example.utils

import android.util.Base64
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

object CryptoUtils {
    private const val ALGORITHM = "AES/CBC/PKCS5Padding"

    private fun generateKey(password: String): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = password.toByteArray(Charsets.UTF_8)
        val keyBytes = digest.digest(bytes)
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun generateIv(password: String): IvParameterSpec {
        val digest = MessageDigest.getInstance("MD5")
        val bytes = password.toByteArray(Charsets.UTF_8)
        val ivBytes = digest.digest(bytes) // md5 returns 16 bytes, perfect for AES IV
        return IvParameterSpec(ivBytes)
    }

    fun encrypt(plainText: String, masterKey: String): String {
        return try {
            val keySpec = generateKey(masterKey)
            val ivSpec = generateIv(masterKey)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(encryptedBytes, Base64.DEFAULT)
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    fun decrypt(encryptedText: String, masterKey: String): String {
        return try {
            val keySpec = generateKey(masterKey)
            val ivSpec = generateIv(masterKey)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            val decodedBytes = Base64.decode(encryptedText, Base64.DEFAULT)
            val decryptedBytes = cipher.doFinal(decodedBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            "Decryption Error: Invalid key or corrupted data"
        }
    }
}
