package com.example.utils

import android.content.Context
import android.net.Uri
import com.example.network.FileIoResponse
import com.example.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object FileUploader {

    suspend fun uploadMedia(context: Context, fileUri: Uri): FileIoResponse = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(fileUri) ?: "application/octet-stream"
            
            // Create a temp file to upload
            val tempFile = File(context.cacheDir, "upload_temp_${System.currentTimeMillis()}")
            val inputStream: InputStream? = contentResolver.openInputStream(fileUri)
            val outputStream = FileOutputStream(tempFile)
            
            inputStream?.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }

            val requestFile = tempFile.asRequestBody(mimeType.toMediaTypeOrNull())
            val body = MultipartBody.Part.createFormData("file", tempFile.name, requestFile)

            val result = NetworkClient.service.uploadFile(body)
            
            // Clean up temp file
            tempFile.delete()
            
            result
        } catch (e: Exception) {
            e.printStackTrace()
            FileIoResponse(success = false, message = e.localizedMessage ?: "Unknown upload error")
        }
    }
}
