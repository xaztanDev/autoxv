package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.example.BuildConfig
import com.example.network.Content
import com.example.network.GenerateContentRequest
import com.example.network.GeminiPart
import com.example.network.GenerationConfig
import com.example.network.InlineData
import com.example.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

object GeminiOcrHelper {

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeReceipt(context: Context, imageUri: Uri): ReceiptResult? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext ReceiptResult(
                description = "Belanjaan (API Key belum di-config)",
                amount = 50000.0,
                success = false,
                message = "API Key belum di-configure di Secrets panel."
            )
        }

        try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(imageUri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap == null) return@withContext null

            val base64Image = bitmap.toBase64()

            val prompt = """
                Analyze this receipt and extract:
                1. A brief summary/description of the expense (e.g., "Makan siang di McD", "Belanja bulanan Indomaret").
                2. The TOTAL amount paid (numeric value only, e.g. 150000.50). 
                
                Respond in strictly valid JSON format with keys:
                {
                   "description": "the summary here",
                   "amount": 125000.00
                }
                Do not include markdown blocks or any other text, only return the raw JSON.
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(
                    Content(
                        parts = listOf(
                            GeminiPart(text = prompt),
                            GeminiPart(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                        )
                    )
                ),
                generationConfig = GenerationConfig(
                    temperature = 0.2f,
                    responseMimeType = "application/json"
                )
            )

            val response = NetworkClient.service.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                // Parse manually or simple regex since we need it robust
                val descRegex = """"description"\s*:\s*"([^"]+)"""".toRegex()
                val amountRegex = """"amount"\s*:\s*([0-9.]+)""".toRegex()

                val desc = descRegex.find(jsonText)?.groupValues?.get(1) ?: "Belanja Struk"
                val amount = amountRegex.find(jsonText)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

                ReceiptResult(desc, amount, true, "Success")
            } else {
                ReceiptResult("Scan Struk Belanja", 0.0, false, "Tidak ada response dari model AI.")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            ReceiptResult("Scan Struk Gagal", 0.0, false, e.localizedMessage ?: "Error")
        }
    }

    suspend fun checkEmailBreach(email: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Koneksi Aman. Hubungkan API Key Gemini di panel Secrets untuk melakukan analisis database breach mendalam."
        }

        try {
            val prompt = """
                Check if the email address "$email" has been found in any historically known data breaches or leaks (like Collection #1, Canva, Adobe, etc.).
                Provide:
                1. A risk level (Low, Medium, High).
                2. A brief, educational explanation of where this email might have been leaked or if it is currently safe.
                3. Actionable security tips (e.g., change passwords, enable 2FA).
                Keep the response concise, clear, and professional in Indonesian language.
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(
                    Content(
                        parts = listOf(
                            GeminiPart(text = prompt)
                        )
                    )
                )
            )

            val response = NetworkClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Tidak dapat memverifikasi email saat ini."
        } catch (e: Exception) {
            "Gagal mengecek: ${e.localizedMessage}"
        }
    }
}

data class ReceiptResult(
    val description: String,
    val amount: Double,
    val success: Boolean,
    val message: String
)
