package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContainer()
            }
        }
    }
}

@Composable
fun SleekTopAppBar(activeScreenId: Int, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(CosmicDarkBg)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (activeScreenId == 0) {
            // Dashboard Header - matching HTML design perfectly
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Gradient squircle with letter 'A'
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF4F6BED), Color(0xFF2C3E50))
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "A",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                }

                // Title & Subtitle
                Column {
                    Text(
                        text = "AutoXV-v1",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicTextPrimary,
                        lineHeight = 22.sp
                    )
                    Text(
                        text = "ALL-IN-ONE POWER SUITE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicPrimary,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Right side search and profile
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = {},
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = CosmicTextPrimary.copy(alpha = 0.6f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Profile Avatar "JD"
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFFD9E2FF), shape = RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "JD",
                        color = Color(0xFF001945),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            // Screen Header with beautiful circular back button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White, shape = RoundedCornerShape(18.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Kembali",
                        tint = CosmicTextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                val screenTitle = when (activeScreenId) {
                    1 -> "Social Downloader"
                    2 -> "Expense & OCR"
                    3 -> "Email Breach Checker"
                    4 -> "Telegram Bot Controller"
                    5 -> "Social Data Backup"
                    6 -> "Media to Link"
                    else -> "AES-256 Vault"
                }

                Text(
                    text = screenTitle,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = CosmicTextPrimary
                )
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    var activeScreenId by remember { mutableStateOf(0) } // 0: Dashboard, 1: Social Downloader, 2: Expense, 3: Email Checker, 4: Bot Telegram, 5: Backup, 6: Media Link, 7: Vault

    Scaffold(
        topBar = {
            SleekTopAppBar(
                activeScreenId = activeScreenId,
                onBack = { activeScreenId = 0 }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CosmicCardBg,
                contentColor = CosmicPrimary,
                modifier = Modifier.navigationBarsPadding(),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeScreenId == 0,
                    onClick = { activeScreenId = 0 },
                    icon = { Icon(imageVector = if (activeScreenId == 0) Icons.Filled.Dashboard else Icons.Outlined.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Home", maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001945),
                        unselectedIconColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        selectedTextColor = Color(0xFF001945),
                        unselectedTextColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        indicatorColor = Color(0xFFD9E2FF)
                    )
                )
                NavigationBarItem(
                    selected = activeScreenId == 1,
                    onClick = { activeScreenId = 1 },
                    icon = { Icon(imageVector = if (activeScreenId == 1) Icons.Filled.Download else Icons.Outlined.Download, contentDescription = "Downloader") },
                    label = { Text("Download", maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001945),
                        unselectedIconColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        selectedTextColor = Color(0xFF001945),
                        unselectedTextColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        indicatorColor = Color(0xFFD9E2FF)
                    )
                )
                NavigationBarItem(
                    selected = activeScreenId == 2,
                    onClick = { activeScreenId = 2 },
                    icon = { Icon(imageVector = if (activeScreenId == 2) Icons.Filled.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet, contentDescription = "Finansial") },
                    label = { Text("Keuangan", maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001945),
                        unselectedIconColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        selectedTextColor = Color(0xFF001945),
                        unselectedTextColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        indicatorColor = Color(0xFFD9E2FF)
                    )
                )
                NavigationBarItem(
                    selected = activeScreenId == 7,
                    onClick = { activeScreenId = 7 },
                    icon = { Icon(imageVector = if (activeScreenId == 7) Icons.Filled.Lock else Icons.Outlined.Lock, contentDescription = "Brankas") },
                    label = { Text("Brankas", maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001945),
                        unselectedIconColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        selectedTextColor = Color(0xFF001945),
                        unselectedTextColor = CosmicTextSecondary.copy(alpha = 0.5f),
                        indicatorColor = Color(0xFFD9E2FF)
                    )
                )
            }
        },
        containerColor = CosmicDarkBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CosmicDarkBg)
        ) {
            when (activeScreenId) {
                0 -> DashboardScreen(onNavigateToFeature = { activeScreenId = it })
                1 -> SocialDownloaderScreen()
                2 -> ExpenseTrackerScreen()
                3 -> EmailBreachCheckerScreen()
                4 -> TelegramBotManagerScreen()
                5 -> BackupArchiverScreen()
                6 -> MediaToLinkScreen()
                7 -> PasswordVaultScreen()
            }
        }
    }
}

