package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.AppDatabase
import com.example.data.VaultItem
import com.example.ui.components.CosmicGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.utils.CryptoUtils
import kotlinx.coroutines.launch

@Composable
fun PasswordVaultScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val db = AppDatabase.getDatabase(context)
    val vaultDao = db.vaultDao()

    var vaultList by remember { mutableStateOf<List<VaultItem>>(emptyList()) }
    var masterKeyInput by varOf("AutoXVSecretPass!") // Default Master Key (Kunci Otak)
    var isMasterKeyVisible by varOf(false)
    var searchQuery by varOf("")

    // Form states
    var titleInput by varOf("")
    var loginIdInput by varOf("")
    var secretInput by varOf("")
    var notesInput by varOf("")

    // Decrypted secrets cache mapped by item ID
    val decryptedSecrets = remember { mutableStateMapOf<Int, String>() }
    // Password visibility mapped by item ID
    val passwordVisibility = remember { mutableStateMapOf<Int, Boolean>() }

    // Fetch vault items
    LaunchedEffect(Unit) {
        vaultDao.getAllVaultItems().collect { list ->
            vaultList = list
        }
    }

    // Filter items by search query
    val filteredList = vaultList.filter {
        it.title.contains(searchQuery, ignoreCase = true) ||
        it.loginId.contains(searchQuery, ignoreCase = true) ||
        it.notes.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Identity & Password Vault",
                subtitle = "Brankas lokal mandiri terenkripsi AES-256 standar militer"
            )
        }

        item {
            // Master Key Config Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Master Password (Kunci Otak)",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Kunci enkripsi & dekripsi hanya tersimpan di memori Anda. Jangan sampai lupa!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CosmicTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = masterKeyInput,
                        onValueChange = { masterKeyInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, tint = CosmicAccent) },
                        trailingIcon = {
                            IconButton(onClick = { isMasterKeyVisible = !isMasterKeyVisible }) {
                                Icon(
                                    imageVector = if (isMasterKeyVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = CosmicTextSecondary
                                )
                            }
                        },
                        visualTransformation = if (isMasterKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicAccent,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )
                }
            }
        }

        item {
            // Add Vault Item Form Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Tambah Akun & Password Baru",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nama Layanan / Judul (e.g. Gmail Utama, Mobile Legend)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = loginIdInput,
                        onValueChange = { loginIdInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Username / Email Login") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = secretInput,
                        onValueChange = { secretInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Password / Token Rahasia") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Catatan Tambahan (Opsional)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    CosmicGradientButton(
                        text = "Enkripsi & Simpan Brankas",
                        onClick = {
                            if (titleInput.isBlank() || loginIdInput.isBlank() || secretInput.isBlank()) {
                                Toast.makeText(context, "Lengkapi semua data utama!", Toast.LENGTH_SHORT).show()
                                return@CosmicGradientButton
                            }
                            if (masterKeyInput.isBlank()) {
                                Toast.makeText(context, "Silakan masukkan Master Password terlebih dahulu!", Toast.LENGTH_SHORT).show()
                                return@CosmicGradientButton
                            }

                            coroutineScope.launch {
                                // Encrypt the secret using Master Key before saving to Room
                                val encrypted = CryptoUtils.encrypt(secretInput, masterKeyInput)
                                val newItem = VaultItem(
                                    title = titleInput,
                                    loginId = loginIdInput,
                                    encryptedData = encrypted,
                                    notes = notesInput
                                )
                                vaultDao.insertVaultItem(newItem)

                                // Clear inputs
                                titleInput = ""
                                loginIdInput = ""
                                secretInput = ""
                                notesInput = ""
                                Toast.makeText(context, "Data terenkripsi AES-256 dan disimpan lokal!", Toast.LENGTH_LONG).show()
                            }
                        },
                        icon = Icons.Default.Lock
                    )
                }
            }
        }

        item {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari akun di dalam brankas...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = CosmicTextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CosmicPrimary,
                    unfocusedBorderColor = CosmicCardBorder,
                    focusedContainerColor = CosmicDarkBg,
                    unfocusedContainerColor = CosmicDarkBg
                )
            )
        }

        if (filteredList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Brankas kosong atau pencarian tidak cocok.", color = CosmicTextSecondary)
                    }
                }
            }
        } else {
            items(filteredList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = CosmicSecondary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = item.title,
                                    color = CosmicTextPrimary,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = {
                                coroutineScope.launch {
                                    vaultDao.deleteVaultItem(item)
                                    decryptedSecrets.remove(item.id)
                                    passwordVisibility.remove(item.id)
                                }
                            }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = RedAlert)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(text = "LOGIN ID / USERNAME", color = CosmicTextSecondary, style = MaterialTheme.typography.labelLarge)
                        Text(text = item.loginId, color = CosmicTextPrimary, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(text = "PASSWORD (AES-256)", color = CosmicTextSecondary, style = MaterialTheme.typography.labelLarge)
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val isVisible = passwordVisibility[item.id] ?: false
                            val displayPass = if (isVisible) {
                                decryptedSecrets[item.id] ?: "••••••••"
                            } else {
                                "••••••••"
                            }
                            Text(
                                text = displayPass,
                                color = if (isVisible) CosmicPrimary else CosmicTextPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                val currentVisible = passwordVisibility[item.id] ?: false
                                if (!currentVisible) {
                                    // Trigger AES decryption using the current Master Key
                                    val decrypted = CryptoUtils.decrypt(item.encryptedData, masterKeyInput)
                                    decryptedSecrets[item.id] = decrypted
                                }
                                passwordVisibility[item.id] = !currentVisible
                            }) {
                                Icon(
                                    imageVector = if (passwordVisibility[item.id] == true) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = CosmicTextSecondary
                                )
                            }
                            IconButton(onClick = {
                                val currentDecrypted = decryptedSecrets[item.id] ?: CryptoUtils.decrypt(item.encryptedData, masterKeyInput)
                                clipboardManager.setText(AnnotatedString(currentDecrypted))
                                Toast.makeText(context, "Password disalin ke clipboard!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Salin", tint = CosmicPrimary)
                            }
                        }

                        if (item.notes.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "NOTES", color = CosmicTextSecondary, style = MaterialTheme.typography.labelLarge)
                            Text(text = item.notes, color = CosmicTextPrimary, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
