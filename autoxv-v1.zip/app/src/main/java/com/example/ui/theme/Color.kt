package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Theme Palette (Modern, airy light-blue aesthetic)
val CosmicDarkBg = Color(0xFFF3F6FF)       // Light clean background
val CosmicCardBg = Color(0xFFFFFFFF)       // Pure White Cards
val CosmicCardBorder = Color(0xFFE9EEFC)   // Subtle light-blue/slate border
val CosmicPrimary = Color(0xFF4F6BED)      // Sleek Electric Blue/Indigo
val CosmicSecondary = Color(0xFF4CAF50)    // Success/Positive Green
val CosmicTertiary = Color(0xFF9C27B0)     // Purple Accent
val CosmicAccent = Color(0xFFFFA000)       // Solar Gold / Alert Orange
val CosmicTextPrimary = Color(0xFF1B1B1F)  // Near-black dark high-contrast text
val CosmicTextSecondary = Color(0xFF64748B)// Modern slate muted subtext
val RedAlert = Color(0xFFFF5A5A)           // Soft sleek crimson error/alert

// Hero Card dark accents
val SleekHeroBg = Color(0xFF1B1B1F)        // Dark background for contrast element
val SleekHeroText = Color(0xFFFFFFFF)      // White text for dark contrast element

