package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.CosmicGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.utils.GeminiOcrHelper
import kotlinx.coroutines.launch

@Composable
fun EmailBreachCheckerScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var emailInput by varOf("")
    var isChecking by varOf(false)
    var resultText by varOf("")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Email Security & Breach Checker",
                subtitle = "Verifikasi apakah email Anda aman dari pembobolan database & hacker"
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Masukkan Alamat Email",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CosmicPrimary) },
                        placeholder = { Text("contoh: emailkamu@gmail.com") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    CosmicGradientButton(
                        text = if (isChecking) "Menganalisis Keamanan..." else "Periksa Status Keamanan",
                        onClick = {
                            if (emailInput.isBlank() || !emailInput.contains("@")) {
                                Toast.makeText(context, "Masukkan format email yang valid!", Toast.LENGTH_SHORT).show()
                                return@CosmicGradientButton
                            }
                            coroutineScope.launch {
                                isChecking = true
                                resultText = "Sedang mensinkronisasikan pencarian database..."
                                val breachResult = GeminiOcrHelper.checkEmailBreach(emailInput)
                                resultText = breachResult
                                isChecking = false
                            }
                        },
                        enabled = !isChecking,
                        icon = Icons.Default.Security
                    )
                }
            }
        }

        if (resultText.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = if (resultText.contains("Koneksi Aman") || resultText.contains("tidak terdeteksi")) CosmicSecondary else RedAlert,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Hasil Analisis Keamanan",
                                style = MaterialTheme.typography.titleLarge,
                                color = CosmicTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = resultText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = CosmicTextPrimary,
                            lineHeight = MaterialTheme.typography.bodyLarge.lineHeight
                        )
                    }
                }
            }
        }

        item {
            // General Info Tips
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg.copy(alpha = 0.5f)),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Rekomendasi Keamanan Rutin",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. Jangan gunakan password yang sama untuk banyak akun sosial media.\n" +
                               "2. Aktifkan Verifikasi 2-Langkah (2FA) menggunakan Google Authenticator atau SMS.\n" +
                               "3. Ganti password Anda setidaknya setiap 3-6 bulan sekali.\n" +
                               "4. Waspadai email Phishing yang meniru instansi resmi meminta password Anda.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CosmicTextSecondary
                    )
                }
            }
        }
    }
}
