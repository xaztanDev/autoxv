package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun DashboardScreen(onNavigateToFeature: (Int) -> Unit) {
    val features = listOf(
        FeatureItem("Social Snatcher", "TT, X, IG, YT DL", Icons.Default.Download, Color(0xFF4F6BED), Color(0xFFE8F1FF), 1),
        FeatureItem("Finance Flow", "Auto OCR Struk", Icons.Default.AccountBalanceWallet, Color(0xFFFF5A5A), Color(0xFFFFF1F1), 2),
        FeatureItem("Breach Guard", "Email Safety Check", Icons.Default.Security, Color(0xFF4CAF50), Color(0xFFF1FFF1), 3),
        FeatureItem("TeleMaster", "Bot Management", Icons.Default.Send, Color(0xFF4F6BED), Color(0xFFF1F3FF), 4),
        FeatureItem("Data Archive", "WA/TG Backups", Icons.Default.Backup, Color(0xFFFFA000), Color(0xFFFFF8E1), 5),
        FeatureItem("Linkify Media", "Files to MP4/MP3", Icons.Default.Link, Color(0xFF9C27B0), Color(0xFFF3E5F5), 6)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // SecureVault Hero Card matching the Sleek HTML perfectly
        Card(
            onClick = { onNavigateToFeature(7) }, // Password Vault is feature index 7
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = SleekHeroBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Radial blue decorative blur circle on top-right
                Box(
                    modifier = Modifier
                        .size(128.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = 30.dp, y = (-30).dp)
                        .background(
                            color = Color(0xFF4F6BED).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(64.dp)
                        )
                )

                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF4F6BED), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "SecureVault",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Text(
                                text = "AES-256 Identity Hub",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Lock Icon Box with white/10% bg
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Lock Icon",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "128 Credentials Protected",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )

                        // Rounded white button
                        Button(
                            onClick = { onNavigateToFeature(7) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = SleekHeroBg
                            ),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "Unlock Vault",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        SectionHeader(
            title = "Aplikasi All-In-One",
            subtitle = "Pilih fitur super lengkap di bawah ini"
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(features) { _, item ->
                Card(
                    onClick = { onNavigateToFeature(item.targetId) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(item.bgColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = null,
                                tint = item.tintColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = item.title,
                                color = CosmicTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.subtitle,
                                color = CosmicTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

data class FeatureItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tintColor: Color,
    val bgColor: Color,
    val targetId: Int
)

