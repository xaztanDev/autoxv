package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AppDatabase
import com.example.data.Expense
import com.example.ui.components.CosmicGradientButton
import com.example.ui.components.MetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.utils.GeminiOcrHelper
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@Composable
fun ExpenseTrackerScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val db = AppDatabase.getDatabase(context)
    val expenseDao = db.expenseDao()

    var expensesList by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var currentBalanceInput by varOf("1000000") // Default balance saldo awal
    var isOcrLoading by varOf(false)

    // Form states
    var descInput by varOf("")
    var amountInput by varOf("")
    var isIncomeType by varOf(false) // default pengeluaran

    // Fetch expenses
    LaunchedEffect(Unit) {
        expenseDao.getAllExpenses().collect { list ->
            expensesList = list
        }
    }

    // Calculations
    val totalExpense = expensesList.filter { !it.isIncome }.sumOf { it.amount }
    val totalIncome = expensesList.filter { it.isIncome }.sumOf { it.amount }
    val initialBalance = currentBalanceInput.toDoubleOrNull() ?: 0.0
    val finalBalance = initialBalance + totalIncome - totalExpense

    // Local ID Currency formatter
    val currencyFormatter = remember {
        NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
        }
    }

    // OCR Receipt Launcher
    val ocrLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isOcrLoading = true
                val result = GeminiOcrHelper.analyzeReceipt(context, uri)
                isOcrLoading = false
                if (result != null) {
                    descInput = result.description
                    amountInput = result.amount.toInt().toString()
                    isIncomeType = false // Receipt belanja is expense
                    Toast.makeText(context, "OCR Berhasil: ${result.description}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Gagal memindai struk belanja.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Finansial & Expense Tracker",
                subtitle = "Kelola pemasukan, pengeluaran & saldo akun bank"
            )
        }

        item {
            // Balance Manager Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Saldo Akun Bank (Awal)",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = currentBalanceInput,
                        onValueChange = { currentBalanceInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = CosmicPrimary) },
                        placeholder = { Text("Masukkan Saldo Akun Bank Anda") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Saldo Akhir Terhitung:", color = CosmicTextSecondary)
                        Text(
                            text = currencyFormatter.format(finalBalance),
                            color = if (finalBalance >= 0) CosmicSecondary else RedAlert,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }
        }

        item {
            // Summary widgets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    MetricCard(
                        title = "Pemasukan",
                        value = currencyFormatter.format(totalIncome),
                        icon = Icons.Default.TrendingUp,
                        accentColor = CosmicSecondary
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    MetricCard(
                        title = "Pengeluaran",
                        value = currencyFormatter.format(totalExpense),
                        icon = Icons.Default.TrendingDown,
                        accentColor = RedAlert
                    )
                }
            }
        }

        item {
            // Entry Form
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Catat Transaksi Manual / OCR",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { isIncomeType = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isIncomeType) RedAlert else CosmicCardBorder,
                                contentColor = if (!isIncomeType) Color.White else CosmicTextSecondary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Pengeluaran", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { isIncomeType = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isIncomeType) CosmicSecondary else CosmicCardBorder,
                                contentColor = if (isIncomeType) Color.White else CosmicTextSecondary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Pemasukan", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Keterangan") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nominal (Rp)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // OCR Button
                        Button(
                            onClick = { ocrLauncher.launch("image/*") },
                            modifier = Modifier.weight(1.2f).height(50.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CosmicTertiary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.DocumentScanner, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isOcrLoading) "Scanning..." else "Scan Struk OCR", maxLines = 1, fontWeight = FontWeight.Bold)
                        }

                        // Save Button
                        Button(
                            onClick = {
                                val amt = amountInput.toDoubleOrNull()
                                if (descInput.isBlank() || amt == null) {
                                    Toast.makeText(context, "Input tidak valid!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                coroutineScope.launch {
                                    expenseDao.insertExpense(
                                        Expense(
                                            description = descInput,
                                            amount = amt,
                                            isIncome = isIncomeType
                                        )
                                    )
                                    descInput = ""
                                    amountInput = ""
                                    Toast.makeText(context, "Catatan transaksi disimpan!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CosmicPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Simpan", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Riwayat Keuangan")
        }

        if (expensesList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Belum ada riwayat keuangan.", color = CosmicTextSecondary)
                    }
                }
            }
        } else {
            items(expensesList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = item.description, color = CosmicTextPrimary, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (item.isIncome) "Pemasukan" else "Pengeluaran",
                                color = if (item.isIncome) CosmicSecondary else RedAlert,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = (if (item.isIncome) "+" else "-") + currencyFormatter.format(item.amount),
                                color = if (item.isIncome) CosmicSecondary else RedAlert,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            IconButton(onClick = {
                                coroutineScope.launch {
                                    expenseDao.deleteExpense(item)
                                }
                            }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = RedAlert)
                            }
                        }
                    }
                }
            }
        }
    }
}
