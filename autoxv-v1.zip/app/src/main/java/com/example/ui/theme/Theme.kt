package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CustomLightColorScheme = lightColorScheme(
    primary = CosmicPrimary,
    secondary = CosmicSecondary,
    tertiary = CosmicTertiary,
    background = CosmicDarkBg,
    surface = CosmicCardBg,
    outline = CosmicCardBorder,
    onPrimary = Color.White,
    onSecondary = CosmicDarkBg,
    onBackground = CosmicTextPrimary,
    onSurface = CosmicTextPrimary,
    error = RedAlert
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CustomLightColorScheme,
        typography = Typography,
        content = content
    )
}

