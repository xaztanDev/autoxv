package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.CosmicGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun TelegramBotManagerScreen() {
    val context = LocalContext.current
    var botTokenInput by varOf("")
    var botNameInput by varOf("")
    var selectedCommandType by varOf(0) // 0: /start, 1: /help, 2: /custom
    var commandResponseInput by varOf("")
    
    var isSavingBot by varOf(false)
    var botLogs by varOf<List<String>>(emptyList())
    var isBotActive by varOf(false)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Telegram Bot Controller",
                subtitle = "Sambungkan dan kelola bot Telegram Anda langsung dari aplikasi"
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Konfigurasi Token Bot (BotFather)",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = botNameInput,
                        onValueChange = { botNameInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nama Bot (e.g. AutoXV_Helper_Bot)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = botTokenInput,
                        onValueChange = { botTokenInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Bot API Token") },
                        placeholder = { Text("123456789:ABCdefGhIJKlmNoPQRsT...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                if (botTokenInput.isBlank()) {
                                    Toast.makeText(context, "Masukkan Token Bot!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                isSavingBot = true
                                botLogs = botLogs + "Menghubungkan ke API Telegram Bot..."
                                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                    botLogs = botLogs + "Sinkronisasi Webhook berhasil!"
                                    botLogs = botLogs + "Bot @${botNameInput.ifBlank { "AutoXV_Bot" }} sekarang AKTIF."
                                    isBotActive = true
                                    isSavingBot = false
                                    Toast.makeText(context, "Bot berhasil diaktifkan!", Toast.LENGTH_SHORT).show()
                                }, 1200)
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isSavingBot) "Menyambungkan..." else "Sambungkan Bot")
                        }

                        if (isBotActive) {
                            Button(
                                onClick = {
                                    isBotActive = false
                                    botLogs = botLogs + "Bot dinonaktifkan."
                                    Toast.makeText(context, "Bot dinonaktifkan.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f).height(50.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RedAlert),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Matikan Bot")
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Pengaturan Command Bot (Settings)",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Tab-like Command Picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("/start", "/help", "Custom").forEachIndexed { index, title ->
                            Button(
                                onClick = { selectedCommandType = index },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedCommandType == index) CosmicTertiary else CosmicDarkBg,
                                    contentColor = CosmicTextPrimary
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(title, maxLines = 1)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = commandResponseInput,
                        onValueChange = { commandResponseInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Respon Auto-Reply Bot") },
                        placeholder = { Text("e.g. Halo! Ada yang bisa dibantu?") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    CosmicGradientButton(
                        text = "Simpan & Terapkan Command",
                        onClick = {
                            if (commandResponseInput.isBlank()) {
                                Toast.makeText(context, "Respon command tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                                return@CosmicGradientButton
                            }
                            val cmdType = listOf("/start", "/help", "Custom")[selectedCommandType]
                            botLogs = botLogs + "Command $cmdType diperbarui dengan respon baru."
                            commandResponseInput = ""
                            Toast.makeText(context, "Command berhasil dikonfigurasi!", Toast.LENGTH_SHORT).show()
                        },
                        icon = Icons.Default.Build
                    )
                }
            }
        }

        item {
            SectionHeader(title = "Log & Aktivitas Realtime Bot")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicDarkBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                if (botLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Belum ada logs aktivitas bot.", color = CosmicTextSecondary)
                    }
                } else {
                    LazyColumn(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                        items(botLogs) { log ->
                            Text(
                                text = "[$] $log",
                                color = if (log.contains("berhasil") || log.contains("AKTIF")) CosmicSecondary else CosmicTextPrimary,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
