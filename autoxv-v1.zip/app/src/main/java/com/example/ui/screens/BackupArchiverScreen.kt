package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.CosmicGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun BackupArchiverScreen() {
    val context = LocalContext.current
    var selectedPlatform by varOf(0) // 0: Telegram, 1: WhatsApp, 2: Instagram, 3: TikTok
    var activeLogs by varOf<List<String>>(emptyList())
    var isArchiving by varOf(false)
    var isDownloadedZip by varOf(false)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Social Data Backup & Archiver",
                subtitle = "Ekstrak dan backup data chat, media, riwayat, audio dari berbagai platform"
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Pilih Platform Sosial Media",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Telegram", "WhatsApp", "Instagram", "TikTok").forEachIndexed { index, name ->
                            Button(
                                onClick = { selectedPlatform = index },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedPlatform == index) CosmicPrimary else CosmicDarkBg,
                                    contentColor = CosmicTextPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 4.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(name, maxLines = 1, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Data yang akan diekstrak & di-backup:",
                        color = CosmicTextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val platformsData = listOf(
                        "Pesan Telegram, Dokumen File, Media Foto, Video, Grup Chat, List Kontak, & History Channel",
                        "Riwayat Chat WhatsApp, Backup File Media, Database enkripsi lokal, Voice Note, & Foto Profil",
                        "Pesan Direct Message (DM), Foto/Video Reels Postingan, Story Archive, Komentar, & List Followers",
                        "Video Draft, History Pencarian, Data Profil, Riwayat Like, Koin Kado, & Data Live Stream"
                    )
                    
                    Text(
                        text = "• " + platformsData[selectedPlatform],
                        color = CosmicTextPrimary,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    CosmicGradientButton(
                        text = if (isArchiving) "Mengekstrak Data..." else "Mulai Backup & Ekstraksi",
                        onClick = {
                            isArchiving = true
                            isDownloadedZip = false
                            val pName = listOf("Telegram", "WhatsApp", "Instagram", "TikTok")[selectedPlatform]
                            activeLogs = activeLogs + "Memulai ekstraksi data $pName..."
                            activeLogs = activeLogs + "Membuat handshake aman dengan server backup lokal..."
                            
                            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                activeLogs = activeLogs + "Mengekstrak riwayat chat & pesan terenkripsi..."
                                activeLogs = activeLogs + "Mengekstrak folder media (Foto, Video, Audio)..."
                                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                    activeLogs = activeLogs + "Mengkompresi semua file menjadi satu file archive (.ZIP)..."
                                    activeLogs = activeLogs + "SELESAI: File backup berhasil dibuat: autoxv_backup_${pName.lowercase()}.zip"
                                    isArchiving = false
                                    isDownloadedZip = true
                                    Toast.makeText(context, "Backup $pName Berhasil!", Toast.LENGTH_LONG).show()
                                }, 1500)
                            }, 1500)
                        },
                        enabled = !isArchiving,
                        icon = Icons.Default.Backup
                    )
                }
            }
        }

        if (isDownloadedZip) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CosmicSecondary.copy(alpha = 0.15f)),
                    border = BorderStroke(1.dp, CosmicSecondary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "File Backup Siap Diunduh!",
                                color = CosmicTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Format: ZIP Archive • Ukuran: ~48.2 MB",
                                color = CosmicTextSecondary,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Button(
                            onClick = {
                                Toast.makeText(context, "Membuka folder unduhan backup ZIP!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicSecondary)
                        ) {
                            Icon(imageVector = Icons.Default.FolderZip, contentDescription = null, tint = CosmicDarkBg)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Buka File", color = CosmicDarkBg, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Progres & Log Aktivitas Ekstraksi")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicDarkBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                if (activeLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Belum ada logs aktivitas backup saat ini.", color = CosmicTextSecondary)
                    }
                } else {
                    LazyColumn(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                        items(activeLogs) { log ->
                            Text(
                                text = "[#] $log",
                                color = if (log.contains("SELESAI") || log.contains("Berhasil")) CosmicSecondary else CosmicTextPrimary,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
