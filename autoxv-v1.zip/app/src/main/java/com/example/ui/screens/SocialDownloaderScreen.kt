package com.example.ui.screens

import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.components.CosmicGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun SocialDownloaderScreen() {
    val context = LocalContext.current
    var urlInput by varOf("")
    var isDownloading by varOf(false)
    var downloadLog by varOf<List<String>>(emptyList())
    var activeTab by varOf(0) // 0: Link Downloader, 1: Embedded Browser

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Social Downloader",
            subtitle = "Download video & foto dari TikTok, X, YouTube, Instagram"
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs to switch mode
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = Color.Transparent,
            contentColor = CosmicPrimary,
            divider = {}
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Link Direct", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Web Browser & Grabber", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == 0) {
            // Direct Link Downloader Layout
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CosmicCardBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Paste Link Postingan",
                        style = MaterialTheme.typography.titleLarge,
                        color = CosmicTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("https://tiktok.com/... atau instagram.com/...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    CosmicGradientButton(
                        text = if (isDownloading) "Menganalisis Link..." else "Download Media",
                        onClick = {
                            if (urlInput.isBlank()) {
                                Toast.makeText(context, "Masukkan URL terlebih dahulu!", Toast.LENGTH_SHORT).show()
                                return@CosmicGradientButton
                            }
                            isDownloading = true
                            downloadLog = downloadLog + "Menganalisis link: $urlInput"
                            downloadLog = downloadLog + "Mengubungi server downloader AutoXV..."
                            
                            // Simulate download steps with delay
                            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                downloadLog = downloadLog + "Media ditemukan! Format: MP4 (Full HD)"
                                downloadLog = downloadLog + "Mengekstrak audio dan video..."
                                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                    downloadLog = downloadLog + "Mengunduh file ke penyimpanan lokal..."
                                    downloadLog = downloadLog + "SELESAI: Berhasil diunduh ke folder /Download/AutoXV"
                                    isDownloading = false
                                    Toast.makeText(context, "Berhasil mengunduh media!", Toast.LENGTH_LONG).show()
                                }, 1500)
                            }, 1500)
                        },
                        enabled = !isDownloading,
                        icon = Icons.Default.Download
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            SectionHeader(title = "Log Aktivitas Unduhan")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = CosmicDarkBg),
                border = CardDefaults.outlinedCardBorder()
            ) {
                if (downloadLog.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Belum ada log unduhan.", color = CosmicTextSecondary)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        items(downloadLog) { log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = CosmicSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = log, color = CosmicTextPrimary, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        } else {
            // Embedded Browser Layout
            var webUrl by varOf("https://www.tiktok.com")
            var currentWebTitle by varOf("Social Web Grabber")
            var hasDetectedMedia by varOf(false)

            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = webUrl,
                        onValueChange = { webUrl = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("Ketik nama website...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedContainerColor = CosmicDarkBg,
                            unfocusedContainerColor = CosmicDarkBg
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            hasDetectedMedia = true
                        },
                        modifier = Modifier
                            .background(CosmicPrimary, RoundedCornerShape(10.dp))
                            .size(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Go", tint = Color.White)
                    }
                }

                if (hasDetectedMedia) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = CosmicSecondary.copy(alpha = 0.2f)),
                        border = BorderStroke(1.dp, CosmicSecondary)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Media Grabber Berhasil Terdeteksi!", color = CosmicTextPrimary, fontWeight = FontWeight.Bold)
                                Text("Format: MP4 Video (High Quality)", color = CosmicTextSecondary, style = MaterialTheme.typography.bodyMedium)
                            }
                            Button(
                                onClick = {
                                    Toast.makeText(context, "Mengunduh media terdeteksi!", Toast.LENGTH_SHORT).show()
                                    hasDetectedMedia = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CosmicSecondary,
                                    contentColor = Color.White
                                )
                            ) {
                                Text("Download", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Simple responsive iframe/webview mock
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, CosmicCardBorder, RoundedCornerShape(12.dp))
                        .background(CosmicCardBg)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        if (url != null) {
                                            webUrl = url
                                        }
                                        hasDetectedMedia = true // simulate smart sniffer trigger
                                    }
                                }
                                settings.javaScriptEnabled = true
                                loadUrl(webUrl)
                            }
                        },
                        update = { webView ->
                            if (webView.url != webUrl) {
                                webView.loadUrl(webUrl)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

// Simple helper to construct mutable state cleanly
@Composable
fun <T> varOf(initial: T): MutableState<T> = remember { mutableStateOf(initial) }
