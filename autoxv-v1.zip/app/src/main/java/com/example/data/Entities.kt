package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- Feature 2: Expense Entity ---
@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val description: String,
    val amount: Double,
    val isIncome: Boolean, // True = Pemasukan, False = Pengeluaran
    val timestamp: Long = System.currentTimeMillis()
)

// --- Feature 7: Vault Item Entity ---
@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val loginId: String,
    val encryptedData: String, // AES-256 encrypted string containing password, token, or secret
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
